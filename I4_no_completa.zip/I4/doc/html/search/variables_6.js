var searchData=
[
  ['gdesc',['gdesc',['../struct__Space.html#ae3774baf0debd56e12b0b7408d94d220',1,'_Space']]]
];
