var searchData=
[
  ['west_5flink',['west_link',['../struct__Space.html#a82797873c5378f322e3232e0147a3bfb',1,'_Space']]],
  ['width',['width',['../struct__Area.html#aa2f753fc3d254821603ac4512db814f1',1,'_Area']]]
];
