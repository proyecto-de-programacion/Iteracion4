var searchData=
[
  ['objects',['objects',['../struct__Game.html#ad45bf5645a26e546d0060a2e61f9cf81',1,'_Game::objects()'],['../struct__Space.html#a661ed8b0fc8085b6db70188aa5085625',1,'_Space::objects()']]],
  ['open',['open',['../struct__Object.html#a0922dd9891e6aa617ce1d51ae27c0175',1,'_Object']]],
  ['original_5flocation',['original_location',['../struct__Object.html#a70df2bf7a3fa2b9b20bd3a20afb2ac26',1,'_Object']]]
];
