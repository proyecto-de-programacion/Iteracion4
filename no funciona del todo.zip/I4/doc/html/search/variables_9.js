var searchData=
[
  ['last_5froll',['last_roll',['../struct__Die.html#a522e4527bd70cf87afcbabd9d9dede34',1,'_Die::last_roll()'],['../struct__Game.html#a20555431bad3ef29425b8637fab1c6f4',1,'_Game::last_roll()']]],
  ['link1',['link1',['../struct__Link.html#a5e7fbb3e1b15bf0cf981153c08be0729',1,'_Link']]],
  ['link2',['link2',['../struct__Link.html#a7ea0ebc1c732428f2cc7e66b6b8832e4',1,'_Link']]],
  ['link_5fid',['link_id',['../struct__Link.html#ae7170e271402273060da61adbac0a41d',1,'_Link']]],
  ['links',['links',['../struct__Game.html#aaa2051f0487f13988148ffd7c5e7ec06',1,'_Game']]]
];
