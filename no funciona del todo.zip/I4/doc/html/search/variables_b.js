var searchData=
[
  ['name',['name',['../struct__Command.html#a8ba0936551626ae41301aa534ba9fc77',1,'_Command::name()'],['../struct__Link.html#a020ee863120055b29609157b9de3c84d',1,'_Link::name()'],['../struct__Object.html#a03fb9b8d91f071e8e30d669be79cc040',1,'_Object::name()'],['../struct__Player.html#ac89715f913cc607b75eb7236765c41f5',1,'_Player::name()'],['../struct__Space.html#aa1c9c994c2d16ecf3ef46138685fdfdc',1,'_Space::name()']]],
  ['north_5flink',['north_link',['../struct__Space.html#a97f50b906e005911d5dd3c1c4453e443',1,'_Space']]],
  ['numarrays',['numArrays',['../struct__Set.html#a308e4cad335bf20808218c49a40ec46e',1,'_Set']]]
];
