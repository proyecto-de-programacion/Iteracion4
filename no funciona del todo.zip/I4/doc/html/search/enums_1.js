var searchData=
[
  ['direction',['DIRECTION',['../types_8h.html#aa268a41a13430b18e933ed40207178d0',1,'types.h']]]
];
