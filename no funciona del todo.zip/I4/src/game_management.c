/** 
 * @brief It implements the game_management interface 
 * 
 * @file game_management.c
 * @author Alexandra Conache
 * @version 3.0 
 * @date 8/03/2019
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/game_management.h"
#include "../include/link.h"
#include "../include/space.h"
#include "../include/object.h"
#include "../include/player.h"




/*!< Load the spaces required from the file */
STATUS game_management_load_spaces(Game* game, char* filename) {
  FILE* file = NULL;
  char line[WORD_SIZE] = "";
  char name[WORD_SIZE] = "";
  char* toks = NULL;
  char firstrow[7];
  char secondrow[7];
  char thirdrow[7];
  char description[WORD_SIZE] = "";
  char illum_description[WORD_SIZE] = "";
  BOOL illum = FALSE;
  
  Space* space = NULL;
  STATUS status = OK;
  
  Id id = NO_ID,
    north_id_link = NO_ID,
    south_id_link = NO_ID,
    east_id_link = NO_ID,
    west_id_link = NO_ID,
    up_id_link = NO_ID,
    down_id_link = NO_ID;


  if (!filename) {
    return ERROR;
  }
  
  file = fopen(filename, "r");
  if (file == NULL) {
    return ERROR;
  }
  /**
 *      What this while does is set where the string read is going to get copied
 *      and it scans the whole file going line by line until it maximum value and 
 *      saves it in "line"
 */ 
  while (fgets(line, WORD_SIZE, file)) {
    /**
     *  The if makes sure the first 3 characters are "#s:" 
     */
    if (strncmp("#s:", line, 3) == 0) {
      /**
       *    Here we cut the string using the character "|"
       *    Here is also where the variables get assigned the right value read from the file
       */
      toks = strtok(line + 3, "|");
      id = atol(toks);
      toks = strtok(NULL, "|");
      strcpy(name, toks);

      toks = strtok(NULL, "|");
      north_id_link = atol(toks);

      toks = strtok(NULL, "|");
      east_id_link = atol(toks);

      toks = strtok(NULL, "|");
      south_id_link = atol(toks);

      toks = strtok(NULL, "|");
      west_id_link = atol(toks);

      toks = strtok(NULL, "|");
      up_id_link = atol(toks);

      toks = strtok(NULL, "|");
      down_id_link = atol(toks);

      toks = strtok(NULL, "|");
      strcpy(firstrow,toks);

      toks = strtok(NULL, "|");
      strcpy(secondrow,toks);

      toks = strtok(NULL, "|");
      strcpy(thirdrow,toks);

      toks = strtok(NULL,"|");
      illum = atoi(toks);

      toks = strtok(NULL,"|");
      strcpy(description, toks);

      toks = strtok(NULL,"|");
      strcpy(illum_description, toks);

      

	#ifdef DEBUG 
      	printf("Leido: %ld|%s|%ld|%ld|%ld|%ld|%ld|%ld|%s|%s|%s|%d|%s|%s|\n", id, name, north_id_link, east_id_link, south_id_link, west_id_link, up_id_link,down_id_link,firstrow,secondrow,thirdrow,illum, description, illum_description);
	#endif
      space = space_create(id);
      if (space != NULL) {
        space_set_name(space, name);
        space_set_north_link(space, north_id_link);
        space_set_east_link(space, east_id_link);
        space_set_south_link(space, south_id_link);
        space_set_west_link(space, west_id_link);
        space_set_up_link(space, up_id_link);
        space_set_down_link(space, down_id_link);
        space_set_gdesc(space,firstrow,0);
        space_set_gdesc(space,secondrow,1);
        space_set_gdesc(space,thirdrow,2);
        space_set_illuminated(space,illum);
        space_set_description(space,description);
        space_set_detail_description(space,illum_description);
        game_add_space(game,space);
      }
    }
  }
  
  if (ferror(file)) {
    status = ERROR;
  }
  
  fclose(file);
  
  return status;
}

/*!< Load the objects required from the file */
STATUS game_management_load_objects(Game* game, char* filename) {
  FILE* file = NULL;
  char line[WORD_SIZE] = "";
  char name[WORD_SIZE] = "";
  char descript[WORD_SIZE] = "";
  char moved_descript[WORD_SIZE] = "";
  char* toks = NULL;
  Id object_id = NO_ID;
  Id space_id = NO_ID;
  Id og_space_id = NO_ID;
  Object* object = NULL;
  STATUS status = OK;
  int num_objects = 0;
  BOOL movable = FALSE, moved = FALSE, hidden = FALSE, illuminate = FALSE, turnedon = FALSE;
  Id open = NO_ID;

  if (!filename) {
    return ERROR;
  }
  
  file = fopen(filename, "r");
  if (file == NULL) {
    return ERROR;
  }
  /**
 *      What this while does is set where the string read is going to get copied
 *      and it scans the whole file going line by line until it maximum value and 
 *      saves it in "line"
 */ 
  while (fgets(line, WORD_SIZE, file) && num_objects < MAX_OBJECTS) {
    /**
     *  The if makes sure the first 3 characters are "#o:" 
     */
    if (strncmp("#o:", line, 3) == 0) {
      /**
       *    Here we cut the string using the character "|"
       *    Here is also where the variables get assigned the right value read from the file
       */
      toks = strtok(line + 3, "|");
      object_id = atol(toks);

      toks = strtok(NULL,"|");
      space_id = atol(toks);

      toks = strtok(NULL,"|");
      og_space_id = atol(toks);

      toks = strtok(NULL,"|");
      strcpy(name, toks);

      toks = strtok(NULL,"|");
      strcpy(descript,toks);

      toks = strtok(NULL,"|");
      strcpy(moved_descript,toks);
      toks = strtok(NULL,"|");
      movable = atoi(toks);
      toks = strtok(NULL,"|");
      moved = atoi(toks);
      toks = strtok(NULL,"|");
      hidden = atoi(toks);
      toks = strtok(NULL,"|");
      illuminate = atoi(toks);
      toks = strtok(NULL,"|");
      turnedon = atoi(toks);
      toks = strtok(NULL,"|");
      open = atol(toks);


	#ifdef DEBUG 
      	printf("Leido: %ld|%ld|%ld|%s|%s|%s|%d|%d|%d|%d|%d|%ld|\n", object_id,space_id, og_space_id, name, descript, moved_descript, movable, moved,hidden,illuminate,turnedon,open);
	#endif
        object = object_create(object_id);
        if(object != NULL){
          
          object_set_name(object,name);
          object_set_description(object,descript);
          /* Posicionar el objeto donde diga el datat.dat */
          game_set_object_space(game,space_id,object_id);
          object_set_original_location(object,og_space_id);
          object_set_moved_description(object,moved_descript);
          object_set_movable(object,movable);
          object_set_moved(object,moved);
          object_set_hidden(object, hidden);
          object_set_illuminate(object,illuminate);
          object_set_turnedon(object,turnedon);
          object_set_open_link(object,open);
          game_add_object(game, object);
          
        }
        num_objects++;
      }
    }
  
  if (ferror(file)) {
    status = ERROR;
  }
  
  fclose(file);
  
  return status;
}

/*!< Load the links required from the file */
STATUS game_management_load_links(Game* game, char* filename) {
  FILE* file = NULL;
  char line[WORD_SIZE] = " ";
  char name[WORD_SIZE] = " ";
  char* toks = NULL;

  Id link_id = NO_ID;
  Id space_link1 = NO_ID;
  Id space_link2 = NO_ID;
  STATE state = DESCONOCIDO;
  Link *link = NULL;
  /*!< We trust the status is OK */
  STATUS status = OK;

  if (!filename) {
    return ERROR;
  }
  
  file = fopen(filename, "r");
  if (file == NULL) {
    return ERROR;
  }
/**
 *      What this while does is set where the string read is going to get copied
 *      and it scans the whole file going line by line until it maximum value and 
 *      saves it in "line"
 */ 
  while (fgets(line, WORD_SIZE, file)) {
    /**
     *  The if makes sure the first 3 characters are "#l:" 
     */
    if (strncmp("#l:", line, 3) == 0) {
      /**
       *    Here we cut the string using the character "|"
       *    Here is also where the variables get assigned the right value read from the file
       */
      toks = strtok(line + 3, "|");
      link_id = atol(toks);
      toks = strtok(NULL, "|");
      strcpy(name, toks);

      toks = strtok(NULL, "|");
      space_link1 = atol(toks);

      toks = strtok(NULL, "|");
      space_link2 = atol(toks);

      toks = strtok(NULL, "|");
      state = atoi(toks);

      #ifdef DEBUG
             printf("Leido: %ld|%s|ld|%ld|%d\n",link_id,name,space_link1,space_link2,state);
      #endif
      
       link = link_create(link_id);
        if(link != NULL){
          link_set_name(link,name);
          link_set_link1(link, space_link1);
          link_set_link2(link, space_link2);
          link_set_state(link, state);
          game_add_link(game,link);
        }
      
      }
    }
  if (ferror(file)) {
    status = ERROR;
  }
  
  fclose(file);
  
  return status;
}

/*!< Load the player from file */
STATUS game_management_load_player(Game* game, char* filename) {
  FILE* file = NULL;
  char *toks = NULL;
  char line[WORD_SIZE] = "";
  STATUS status = ERROR;
  Player* player;
  Id id;
  char name[WORD_SIZE +1];
  Id location = NO_ID; 
  Id arID = NO_ID;
  int i = 0;

  if (!filename) {
    return ERROR;
  }
  
  file = fopen(filename, "r");
  if (file == NULL) {
    return ERROR;
  }

  while (fgets(line, WORD_SIZE, file)) {
      if (strncmp("#p:", line, 3) == 0) {
        toks = strtok(line + 3, "|");
        id = atol(toks);
        toks = strtok(NULL, "|");
        strcpy(name, toks);
        toks = strtok(NULL, "|");
        location = atol(toks);
        

        #ifdef DEBUG
             printf("Leido: %ld|%s|%ld|%ld|%ld|%ld|%ld|%ld|%ld|\n",id,name,location,arID[0],arID[1],arID[2],arID[3],arID[4],arID[5]);
        #endif

        player = player_create(id);
        if (player != NULL) {
          player_set_name(player, name);
          player_set_location(player, location);
          
          while(toks != NULL){
            toks = strtok(NULL, "|");
            arID = atol(toks);
            if(arID == NO_ID) break;
            player_set_inventory(player, arID);
            i++;  
          }
          
          status = game_add_player(game, player);
        }
      }
  }
  if (ferror(file)) {
    status = ERROR;
  }
  
  fclose(file);
  
  return status;
}

STATUS game_management_load_game(Game* game, char* filename){
  FILE* f = NULL;
  char aux[WORD_SIZE + 1] = "";
  STATUS auxspace = OK,
  auxlink = OK,
  auxobject = OK,
  auxplayer = OK,
  auxstatus = OK;

  /*opens a file to update both reading and writing and the file must exist*/
  f = fopen(filename, "r+");
  if(!f) return ERROR;

  while (fgets(aux, WORD_SIZE, f) != NULL){
    if(strncmp("#s:", aux, 3) == 0){
      auxspace = game_management_load_spaces(game, aux + 3);
    }else if(strncmp("#o:", aux, 3) == 0){
      auxlink = game_management_load_objects(game, aux + 3);
    }else if(strncmp("#l:", aux, 3) == 0){
      auxobject = game_management_load_links(game, aux + 3);
    }else if(strncmp("#p:", aux, 3) == 0){
      auxplayer = game_management_load_player(game, aux + 3);
    }else{
      break;
    }
  }
  if(ferror(f)){
    auxstatus = ERROR;
  }

  fclose(f);
  if((auxlink) == OK && OK == (auxspace) && OK == (auxobject) && (auxplayer) == OK){
    return auxstatus;
  }

  return ERROR;
}

STATUS game_management_save_game(Game* game, char* filename){
  FILE *f = NULL;
  int i = 0;
  char firstrow[7];
  char secondrow[7];
  char thirdrow[7];
  char description[WORD_SIZE] = "";
  char illum_description[WORD_SIZE] = "";
  BOOL illum = FALSE;
  Id id = NO_ID,
    north_id_link = NO_ID,
    south_id_link = NO_ID,
    east_id_link = NO_ID,
    west_id_link = NO_ID,
    up_id_link = NO_ID,
    down_id_link = NO_ID;
  char descript[WORD_SIZE] = "";
  char moved_descript[WORD_SIZE] = "";
  Id object_id = NO_ID;
  Id space_id = NO_ID;
  Id og_space_id = NO_ID;
  BOOL movable = FALSE, moved = FALSE, hidden = FALSE, illuminate = FALSE, turnedon = FALSE;
  Id open = NO_ID;
  Id link_id = NO_ID;
  Id space_link1 = NO_ID;
  Id space_link2 = NO_ID;
  STATE state = DESCONOCIDO;
  char name[WORD_SIZE+1] = "";
  Id location;
  Id arID[TAM_ID + 1];
  Set* set = NULL;

  if(!game || !filename) return ERROR;
  /* w+ creates an empty file that can be written and read */
  f = fopen(filename,"w+");
  if(!f) return ERROR;
  
  for(i = 0; i < MAX_SPACES && game_get_space(game,i) != NULL; i++){
    id = space_get_id(game_get_space(game, i));
    if(id == NO_ID) return ERROR;
    if(!strcpy(name,space_get_name(game_get_space(game, i)))) return ERROR;
    north_id_link = space_get_north_link(game_get_space(game, i));
    south_id_link = space_get_south_link(game_get_space(game, i));
    east_id_link = space_get_east_link(game_get_space(game, i));
    west_id_link = space_get_west_link(game_get_space(game, i));
    up_id_link = space_get_up_link(game_get_space(game, i));
    down_id_link = space_get_down_link(game_get_space(game, i));
    if(!strcpy(firstrow,space_get_gdesc1(game_get_space(game, i)))) return ERROR;
    if(!strcpy(secondrow,space_get_gdesc2(game_get_space(game, i)))) return ERROR;
    if(!strcpy(thirdrow,space_get_gdesc3(game_get_space(game, i)))) return ERROR;
    illum = space_get_illuminated(game_get_space(game, i));
    if(!strcpy(description,space_get_description(game_get_space(game, i)))) return ERROR;
    if(!strcpy(illum_description,space_get_detail_description(game_get_space(game, i)))) return ERROR;

    fprintf(f,"%ld|%s|%ld|%ld|%ld|%ld|%ld|%ld|%s|%s|%s|%d|%s|%s|\n", id, name, north_id_link, east_id_link, south_id_link, west_id_link, up_id_link,down_id_link,firstrow,secondrow,thirdrow,illum, description, illum_description);
  }

  
  for(i = 0; i < MAX_OBJECTS && game_get_object(game,i) != NULL; i++){
  
      object_id = object_get_id(game_get_object(game,i));
      if(object_id == NO_ID) return ERROR;
      space_id = game_get_object_location(game, game_get_object(game,i));
      if(space_id == NO_ID) return ERROR;
      og_space_id = object_get_original_location(game_get_object(game,i));
      if(og_space_id == NO_ID) return ERROR;
      if(!strcpy(name,object_get_name(game_get_object(game,i)))) return ERROR;
      if(!strcpy(descript,object_get_description(game_get_object(game,i)))) return ERROR;
      if(!strcpy(moved_descript,object_get_moved_description(game_get_object(game,i)))) return ERROR;

      movable = object_get_movable(game_get_object(game,i));
      moved = object_get_moved(game_get_object(game,i));
      hidden = object_get_hidden(game_get_object(game,i));
      illuminate = object_get_illuminate(game_get_object(game,i));
      turnedon = object_get_turnedon(game_get_object(game,i));

      open = object_get_open_link(game_get_object(game,i));

      fprintf(f,"%ld|%ld|%ld|%s|%s|%s|%d|%d|%d|%d|%d|%ld|\n", object_id,space_id, og_space_id, name, descript, moved_descript, movable, moved,hidden,illuminate,turnedon,open);
  }
  
  
  for(i = 0; i < MAX_LINK && game_get_link(game,i) != NULL; i++){
    link_id = link_get_id(game_get_link(game,i));
    if(link_id == NO_ID) return ERROR;
    if(!strcpy(name,link_get_name(game_get_link(game,i)))) return ERROR;
    space_link1 = link_get_link1(game_get_link(game,i));
    space_link2 = link_get_link2(game_get_link(game,i));
    state = link_get_state(game_get_link(game,i));
    if(state == DESCONOCIDO) return ERROR;

    fprintf(f,"%ld|%s|%ld|%ld|%d|\n",link_id,name,space_link1,space_link2,state);
  }

  

  
  id = player_get_id(game_get_player(game));
  if(id == NO_ID) return ERROR;
  if(!strcpy(name,player_get_name(game_get_player(game)))) return ERROR;
  location = player_get_location(game_get_player(game));
  if (location == NO_ID) return ERROR;
  for(i = 0;i < MAX_PLAYER_OBJECTS;i++){
    set = inventory_get_set(player_get_inventory(game_get_player(game)));
    arID[i] = set_get_id(set,i);
  }
  
  
  fprintf(f,"%ld|%s|%ld|%ld|%ld|%ld|%ld|%ld|%ld|\n",id,name,location,arID[0],arID[1],arID[2],arID[3],arID[4],arID[5]);

  fclose(f);

  return OK; 
}

