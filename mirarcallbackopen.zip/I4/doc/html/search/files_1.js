var searchData=
[
  ['die_2ec',['die.c',['../die_8c.html',1,'']]],
  ['die_2eh',['die.h',['../die_8h.html',1,'']]]
];
