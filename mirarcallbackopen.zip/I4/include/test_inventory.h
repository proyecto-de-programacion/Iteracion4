/** 
 * @brief It declares the tests for the inventory module
 * 
 * @file test_inventory.h
 * @author CiroAlonso
 * @version 1.0 
 * @date 10-04-19
*/

#ifndef TEST_INVENTORY_H
#define TEST_INVENTORY_H

/**
 *      @test   Tests the inventory creation function
 *      @pre Parameters: a non NULL inventory pointer
 *      @post   Return: a non NULL pointer to the inventory created
 */
void test1_inventory_create();

/**
 *      @test   Tests the object creation function
 *      @pre Parameters: a NULL inventory pointer
 *      @post   Return: a NULL pointer to the inventory created
 */
void test2_inventory_create();

/**
 *      @test   Tests the set maxObjects function
 *      @pre    Parameter: an Id, an Inventory structure
 *      @post   Return: OK 
 */
void test1_inventory_set_maxObjects();

/**
 *      @test   Tests the set maxObjects function
 *      @pre    Parameter: an Id, an Inventory structure
 *      @post   Return: ERROR 
 */
void test2_inventory_set_maxObjects();

/**
 *      @test   Tests the get set function
 *      @pre    Parameter:  an Inventory structure
 *      @post   Return: the set structure 
 */
void test1_inventory_get_set();

/**
 *      @test   Tests the get set function
 *      @pre    Parameter: an Inventory structure
 *      @post   Return: a NULL pointer 
 */
void test2_inventory_get_set();

/**
 *      @test   Tests the get maxObjects function
 *      @pre    Parameter:  an Inventory structure
 *      @post   Return: maxObjects of the inventary 
 */
void test1_inventory_get_maxObjects();

/**
 *      @test   Tests the get maxObjects function
 *      @pre    Parameter:  an Inventory structure
 *      @post   Return: NO_ID
 */
void test2_inventory_get_maxObjects();

/**
 *      @test   Tests the set_set function
 *      @pre    Parameter: an Id to add to the inventory
 *      @post   Return: OK 
 */
void test1_inventory_add_object();

/**
 *      @test   Tests the set_set function
 *      @pre    Parameter: an Id to add to the inventory
 *      @post   Return: ERROR 
 */
void test2_inventory_add_object();

/**
 *      @test   Tests the delete object function
 *      @pre    Parameter: an Id to delete from the inventory
 *      @post   Return: OK 
 */
void test1_inventory_delete_object();

/**
 *      @test   Tests the delete object function
 *      @pre    Parameter: an Id to delete from the inventory
 *      @post   Return: ERROR 
 */
void test2_inventory_delete_object();

/**
 *      @test   Tests the delete object function
 *      @pre    Parameter: an Id to delete from the inventory
 *      @post   Return: ERROR 
 */
void test3_inventory_delete_object();

/**
 *      @test   Tests the ask id function
 *      @pre    Parameter: an Id to search for from the inventory
 *      @post   Return: OK 
 */
void test1_inventory_ask_id();

/**
 *      @test   Tests the ask id function
 *      @pre    Parameter: an Id to search for from the inventory
 *      @post   Return: OK 
 */
void test2_inventory_ask_id();

/**
 *      @test   Tests the ask id function
 *      @pre    Parameter: an Id to search for from the inventory
 *      @post   Return: OK 
 */
void test3_inventory_ask_id();

/**
 *      @test Test the ask the inventorie's id function
 *      @pre  Pareameter: a NULL inventory pointer
 *      @post Return: NO_ID
 */
void test1_inventory_get_id();
/**
 *      @test Test the ask the inventorie's id function
 *      @pre  Pareameter: an id for the inventory
 *      @post Return: the id provided
 */
void test2_inventory_get_id();
#endif