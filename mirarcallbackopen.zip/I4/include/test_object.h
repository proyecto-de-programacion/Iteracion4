/**
 *      @brief Declares the tests for the object module
 * 
 *      @file test_object.h
 *      @author Alexandra Conache
 *      @version 1.0
 *      @date 08-04-2019
 * 
 * 
 */

#ifndef TEST_OBJECT_H
#define TEST_OBJECT_H


/**
 *      @test   Tests the object creation function
 *      @pre    Parameter: an Id
 *      @post   Return: a non NULL pointer to the object created
 */
void test1_object_create();
/**
 *      @test   Tests the object creation function
 *      @pre    Parameter: an Id
 *      @post   Return: the object's Id is the one we inputed
 */
void test2_object_create();
/**
 *      @test   Tests the return the object's id function
 *      @pre    Parameter: an Id
 *      @post   Return: the object's id is the one we inputed
 */
void test1_object_get_id();
/**
 *      @test   Tests the return the object's id function
 *      @pre    Parameter: NULL object
 *      @post   Return: the object has NO_ID assigned
 */
void test2_object_get_id();
/**
 *      @test   Tests the assign an object's name function
 *      @pre    Parameter: the name we want to assign
 *      @post   Return: has to be OK
 */
void test1_object_set_name();
/**
 *      @test   Tests the assign an object's name function
 *      @pre    Parameter: the name we want to assign
 *      @post   Return: has to be ERROR
 */
void test2_object_set_name();
/**
 *      @test   Tests the assign an object's description function
 *      @pre    Parameter: the description we want to assign
 *      @post   Return: has to be OK
 */
void test1_object_set_description();
/**
 *      @test   Tests the assign an object's description function
 *      @pre    Parameter: the description we want to assign
 *      @post   Return: has to be different than OK
 */
void test2_object_set_description();
/**
 *      @test   Tests the return an object's name function
 *      @pre    Parameter: the name we assigned to the object
 *      @post   Return: has to be 0 for the string comparison we did
 */
void test1_object_get_name();
/**
 *      @test   Tests the return an object's name function
 *      @pre    Parameter: a NULL object
 *      @post   Return: has to be NULL
 */
void test2_object_get_name();
/**
 *      @test   Tests the return an object's description function
 *      @pre    Parameter: the description we assigned to the object
 *      @post   Return: has to be 0 for the string comparison we did
 */
void test1_object_get_description();
/**
 *      @test   Tests the return an object's description function
 *      @pre    Parameter: a NULL object
 *      @post   Return: has to be NULL
 */
void test2_object_get_description();

/**
 *      @test Tests the assign an object the movable status true or false
 *      @pre  Parameter: an id for the object and a TRUE value for the function
 *      @post Return: must be OK
 */
void test1_object_set_movable();
/**
 *      @test Tests the assign an object the movable status true or false
 *      @pre  Parameter: TRUE as an argument for the function 
 *      @post Return: must be ERROR
 */
void test2_object_set_movable();
/**
 *      @test Tests the return whether the object is movable or not function
 *      @pre  Parameter: an Id for the object, TRUE as the set function argument
 *      @post Return: must be TRUE
 */
void test1_object_get_movable();
/**
 *      @test Tests the return whether the object is movable or not function
 *      @pre  Parameter: a NULL object
 *      @post Return: must be FALSE
 */
void test2_object_get_movable();
/**
 *      @test Tests the check if an object has been moved or not function
 *      @pre  Parameter: an Id for the object and an Id for the space it's from
 *      @post Return: must return OK
 */
void test1_object_set_moved(); 
/**
 *      @test Tests the check if an object has been moved or not function
 *      @pre  Parameter: a NULL object pointer and an Id for the space it's from
 *      @post Return: must return ERROR
 */
void test2_object_set_moved();
/**
 *      @test Tests the return TRUE or FALSE if the object's been moved function
 *      @pre  Parameter: An id for the object, an id for the og location and an id for the space moved
 *      @post Return: must return TRUE
 */
void test1_object_get_moved();
/**
 *      @test Tests the return TRUE or FALSE if the object's been moved function
 *      @pre  Parameter: a NULL object pointer
 *      @post Return: must return FALSE
 */
void test2_object_get_moved();
/**
 *      @test Tests the assign an object an original location function
 *      @pre  Parameter: an Id for the object and an id for the objects's space of origin
 *      @post Return: must return OK
 */
void test1_object_set_original_location();
/**
 *      @test Tests the assign an object an original location function
 *      @pre  Parameter: a NULL object pointer
 *      @post Return: must return ERROR
 */
void test2_object_set_original_location();
/**
 *      @test Tests the return the object's original location function
 *      @pre  Parameter: an id for the object and an id for the og location
 *      @post Return: must return 2
 */
void test1_object_get_original_location();
/**
 *      @test Tests the return the object's original location function
 *      @pre  Parameter: a NULL object pointer
 *      @post Return: must return NO_ID
 */
void test2_object_get_original_location();
/**
 *      @test Tests the make the object be hidden or not function
 *      @pre  Parameter: an id for the object and TRUE it is hidden
 *      @post Return: must return OK
 */
void test1_object_set_hidden();
/**
 *      @test Tests the make the object be hidden or not function
 *      @pre  Parameter: a NULL object pointer and FALSE it isn't hidden
 *      @post Return: must return ERROR
 */
void test2_object_set_hidden();
/**
 *      @test Tests the return the hidden status of an object function
 *      @pre  Parameter: an id for the object and TRUE it is hidden
 *      @post Return: must return TRUE
 */
void test1_object_get_hidden();
/**
 *      @test Tests the return the hidden status of an object function
 *      @pre  Parameter: a NULL object pointer
 *      @post Return: must return TRUE
 */
void test2_object_get_hidden();
/**
 *      @test Tests the set a description for an object that's been moved
 *      @pre  Parameter: an id for the object and a description
 *      @post Return: must return OK
 */
void test1_object_set_moved_description();
/**
 *      @test Tests the set a description for an object that's been moved
 *      @pre  Parameter: a NULL object pointer
 *      @post Return: must return ERROR
 */
void test2_object_set_moved_description();
/**
 *      @test Tests the get the description of the object that's been moved
 *      @pre  Parameter: an id for the object and a description
 *      @post Return: must return 0
 */
void test1_object_get_moved_description();
/**
 *      @test Tests the get the description of the object that's been moved
 *      @pre  Parameter: a NULL object pointer
 *      @post Return: must return something different than 0
 */
void test2_object_get_moved_description();



/**
 *      @test Tests the assign of the set open function
 *      @pre  Parameter: an id for the object and one for the link
 *      @post Return: must return OK
 */
void test1_object_set_open_link();

/**
 *      @test Tests the assign of the set open function
 *      @pre  Parameter: a NULL object pointer and an id for the link
 *      @post Return: must return ERROR
 */
void test2_object_set_open_link();

/**
 *      @test Tests the if it gets the open link Id
 *      @pre  Parameter: an id for the object and one for the link
 *      @post Return: must return 14
 */
void test1_object_get_open_link();

/**
 *      @test Tests the if it gets the open link Id
 *      @pre  Parameter: a NULL object pointer
 *      @post Return: must return NO_ID
 */
void test2_object_get_open_link();

/**
 *      @test Tests if it returns the illuminate state
 *      @pre  Parameter: an id for the object and TRUE the object illuminates
 *      @post Return: must return TRUE
 */
void test1_object_get_illuminate();

/**
 *      @test Tests if it returns the illuminate state
 *      @pre  Parameter: a NULL object pointer
 *      @post Return: must return FALSE
 */
void test2_object_get_illuminate();

/**
 *      @test Tests the assign of the state of illuminate
 *      @pre  Parameter: an id for the object and FALSE it can't illuminate
 *      @post Return: must return OK
 */
void test1_object_set_illuminate();

/**
 *      @test Tests the assign of the state of illuminate
 *      @pre  Parameter: a NULL object pointer
 *      @post Return: must return ERROR
 */
void test2_object_set_illuminate();

/**
 *      @test Tests if it returns the turnedon state
 *      @pre  Parameter: an object id, TRUE the object can illuminate and TRUE the object is turned on
 *      @post Return: must return TRUE
 */
void test1_object_get_turnedon();

/**
 *      @test Tests if it returns the turnedon state
 *      @pre  Parameter: a NULL object pointer
 *      @post Return: must return FALSE
 */
void test2_object_get_turnedon();

/**
 *      @test Tests the assign of the state of turnedon
 *      @pre  Parameter: an id for the object, TRUE it can illuminate and TRUE it is turned on
 *      @post Return: must return OK
 */
void test1_object_set_turnedon();

/**
 *      @test Tests the assign of the state of turnedon
 *      @pre  Parameter: a NULL object pointer and TRUE it is turned on
 *      @post Return: must return ERROR
 */
void test2_object_set_turnedon();
#endif
