
/**
 * @brief Tests the player module
 * 
 * @file   test_player.c
 * @author Alexandra Conache
 * @version 1.0
 * @date 08/04/2019
 *   
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../include/player.h"
#include "../include/inventory.h"
#include "../include/test_player.h"
#include "../include/test.h"

#define MAX_TESTS 22 /*!< Maximum number of tests */
/**
 * @brief Runs the test
 * @param argc first argument
 * @param *argv[] second argument
 * 
 */
int main(int argc, char** argv) {

    int test = 0;
    int all = 1;

    if (argc < 2) {
        printf("Running all test for module Player:\n");
    } else {
        test = atoi(argv[1]);
        all = 0;
        printf("Running test %d:\t", test);
        if (test < 1 && test > MAX_TESTS) {
            printf("Error: unknown test %d\t", test);
            exit(EXIT_SUCCESS);
        }
    }


    if (all || test == 1) test1_player_create();
    if (all || test == 2) test2_player_create();
    if (all || test == 3) test1_player_get_id();
    if (all || test == 4) test2_player_get_id();
    if (all || test == 5) test1_player_set_name();
    if (all || test == 6) test2_player_set_name();
    if (all || test == 7) test1_player_set_inventory();
    if (all || test == 8) test2_player_set_inventory();
    if (all || test == 9) test1_player_get_name();
    if (all || test == 10) test2_player_get_name();
    if (all || test == 11) test1_player_get_inventory();
    if (all || test == 12) test2_player_get_inventory();
    if (all || test == 13) test1_player_set_location();
    if (all || test == 14) test2_player_set_location();
    if (all || test == 15) test1_player_get_location();
    if (all || test == 16) test2_player_get_location();
    if (all || test == 17) test1_player_drop_object();
    if (all || test == 18) test2_player_drop_object();
    if (all || test == 19) test2_player_has_object();
    if (all || test == 20) test2_player_has_object();
    


    PRINT_PASSED_PERCENTAGE;

    return 1;
}

/*
 *      First player_create test
 */
void test1_player_create(){
    Player *p = NULL;

    p = player_create(1);
    PRINT_TEST_RESULT(p != NULL);
    player_destroy(p);
}
/*
 *      Second player_create test
 */
void test2_player_create(){
    Player *p = NULL;
    p = player_create(NO_ID);
    PRINT_TEST_RESULT(p == NULL);
}
/*
 *      First player_get_id test
 */
void test1_player_get_id(){
    Player *p =NULL;
    p = player_create(1);
    PRINT_TEST_RESULT(player_get_id(p) == 1);
    player_destroy(p);
}
/*
 *      Second player_get_id test
 */
void test2_player_get_id(){
    Player *p = NULL;
    PRINT_TEST_RESULT(player_get_id(p)==NO_ID);
}
/*
 *      First player_set_name test
 */
void test1_player_set_name(){
    Player *p = NULL;
    p = player_create(1);
    player_set_name(p,"DAB MASTER");
    PRINT_TEST_RESULT(strcmp(player_get_name(p),"DAB MASTER") == 0);
    player_destroy(p);
}
/*
 *      Second player_set_name test
 */
void test2_player_set_name(){
    Player *p = NULL;
    PRINT_TEST_RESULT(player_set_name(p,"LOSER") == ERROR);
}
/*
 *      First player_set_inventory test
 */
void test1_player_set_inventory(){
    Player *p = NULL;

    p = player_create(1);
    
    PRINT_TEST_RESULT(player_set_inventory(p,3) == OK);
    player_destroy(p);
}
/*
 *      Second player_set_inventory test
 */
void test2_player_set_inventory(){
    Player *p = NULL;
    PRINT_TEST_RESULT(player_set_inventory(p,NO_ID) == ERROR);
}
/*
 *      First player_get_name test
 */
void test1_player_get_name(){
    Player *p = NULL;
    p = player_create(1);
    player_set_name(p,"DAB MASTER");
    PRINT_TEST_RESULT(strcmp(player_get_name(p),"DAB MASTER")==0);
    player_destroy(p);
}
/*
 *      Second player_get_name test
 */
void test2_player_get_name(){
    Player *p = NULL;
    PRINT_TEST_RESULT(player_get_name(p) == NULL);
}
/*
 *      First player_get_inventory test
 */
void test1_player_get_inventory(){
    Player *p = NULL;

    p = player_create(1);
    player_set_inventory(p,3);

    PRINT_TEST_RESULT(player_get_inventory(p) != NULL);
    player_destroy(p);
}
/*
 *      Second player_get_inventory test
 */
void test2_player_get_inventory(){
    Player *p = NULL;
    PRINT_TEST_RESULT(player_get_inventory(p) == NULL);
}
/*
 *      First player_set_location test
 */
void test1_player_set_location(){
    Player *p = NULL;

    p = player_create(1);
    PRINT_TEST_RESULT(player_set_location(p,2) == OK);
    player_destroy(p);
}
/*
 *      Second player_set_location test
 */
void test2_player_set_location(){
    Player *p = NULL;
    PRINT_TEST_RESULT(player_set_location(p,NO_ID) != OK);
}
/*
 *      First player_get_location test
 */
void test1_player_get_location(){
    Player *p = NULL;
    p = player_create(1);
    player_set_location(p,1);
    PRINT_TEST_RESULT(player_get_location(p) == 1);
    player_destroy(p);
}
/*
 *      Second player_get_location test
 */
void test2_player_get_location(){
    Player *p = NULL;
    PRINT_TEST_RESULT(player_get_location(p) == NO_ID);
}
/*
 *      First player_drop_object test
 */
void test1_player_drop_object(){
    Player *p = NULL;

    p = player_create(1);
    PRINT_TEST_RESULT(player_drop_object(p,9) == ERROR);
    player_destroy(p);
}
/*
 *      Second player_drop_object test
 */
void test2_player_drop_object(){
    Player *p = NULL;
    PRINT_TEST_RESULT(player_drop_object(p,NO_ID) != OK);
}
/*
 *      First player_has_object test
 */
void test1_player_has_object(){
    Player *p = NULL;
    p = player_create(1);
    PRINT_TEST_RESULT(player_has_object(p,3) == ERROR);
    player_destroy(p);
}
/*
 *      Second player_has_object test
 */
void test2_player_has_object(){
    Player *p = NULL;
    PRINT_TEST_RESULT(player_has_object(p,NO_ID) != OK);
}


/*
 *      THE END... For Now  
 */
