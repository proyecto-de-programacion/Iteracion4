/** 
 * @brief It tests link module
 * 
 * @file test_link.c
 * @author CiroAlonso
 * @version 1.0
 * @date 10-04-2019
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/link.h"
#include "../include/test_link.h"
#include "../include/test.h"

#define MAX_TESTS 12 /*!< Maximum number of tests */

/** 
 * @brief Funcion principal de pruebas para el modulo Link. 
 * 
 * Dos modos de ejecucion:
 *   1.-Si se ejecuta sin parametros se ejecutan todas las pruebas 
 *   2.-Si se ejecuta con un numero entre 1 y el numero de pruebas solo ejecuta 
 *      la prueba indicada  
 *  
 */

/**
 * @brief Runs the test
 * @param argc first argument
 * @param *argv[] second argument
 * 
 */
int main(int argc, char** argv) {

    int test = 0;
    int all = 1;

    if (argc < 2) {
        printf("Running all test for module Link:\n");
    } else {
        test = atoi(argv[1]);
        all = 0;
        printf("Running test %d:\t", test);
        if (test < 1 && test > MAX_TESTS) {
            printf("Error: unknown test %d\t", test);
            exit(EXIT_SUCCESS);
        }
    }


    if (all || test == 1) test1_link_create();
    if (all || test == 2) test2_link_create(); 
    if (all || test == 3) test1_link_set_name();
    if (all || test == 4) test2_link_set_name();
    if (all || test == 5) test1_link_set_link1();
    if (all || test == 6) test2_link_set_link1();
    if (all || test == 7) test1_link_set_link2();
    if (all || test == 8) test2_link_set_link2();
    if (all || test == 9) test1_link_set_state();
    if (all || test == 10) test2_link_set_state();
    if (all || test == 11) test1_link_get_id();
    if (all || test == 12) test2_link_get_id();
    if (all || test == 13) test1_link_get_name();
    if (all || test == 14) test2_link_get_name();
    if (all || test == 15) test1_link_get_link1();
    if (all || test == 16) test2_link_get_link1();
    if (all || test == 17) test1_link_get_link2();
    if (all || test == 18) test2_link_get_link2();
    if (all || test == 19) test1_link_get_state();
    if (all || test == 20) test2_link_get_state();


    PRINT_PASSED_PERCENTAGE;

    return 1;
}

/*
 *  First link_create test
 */
void test1_link_create(){
    Link *pp =NULL;
    pp = link_create(7);

    PRINT_TEST_RESULT(link_get_id(pp) == 7);
    link_destroy(pp);
}

/*
 *  Second link_create test
 */
void test2_link_create(){
    Link *podemos =NULL;
    podemos = link_create(15);

    PRINT_TEST_RESULT(podemos != NULL);
    link_destroy(podemos);
}



/*
 *  First set_name test
 */
void test1_link_set_name(){
    Link *pl = NULL;
    pl = link_create(23);

    PRINT_TEST_RESULT(link_set_name(pl, "QUE")== OK);
    link_destroy(pl);
}

/*
 *  Second set_name test
 */
void test2_link_set_name(){
    Link *pl = NULL;

    PRINT_TEST_RESULT(link_set_name(pl, "WAPO SOI")==ERROR);
}



/*
 *  First set_link1 test
 */
void test1_link_set_link1(){
    Link *pl = NULL;
    pl = link_create(23);

    PRINT_TEST_RESULT(link_set_link1(pl, 7)== OK);
    link_destroy(pl);
}

/*
 *  Second set_link1 test
 */
void test2_link_set_link1(){
    Link *pl = NULL;

    PRINT_TEST_RESULT(link_set_link1(pl, 7)== ERROR);
}


/*
 *  First set_link2 test
 */
void test1_link_set_link2(){
    Link *pl = NULL;
    pl = link_create(21);

    PRINT_TEST_RESULT(link_set_link2(pl, 34)== OK);
    link_destroy(pl);
}

/*
 *  Second set_link2 test
 */
void test2_link_set_link2(){
    Link *pl = NULL;

    PRINT_TEST_RESULT(link_set_link2(pl, 34)== ERROR);
}



/*
 *  First set_state test
 */
void test1_link_set_state(){
    Link *pl = NULL;
    pl = link_create(45);

    PRINT_TEST_RESULT(link_set_state(pl, CERRADO) == OK);
    link_destroy(pl);

}

/*
 *  Second set_state test
 */
void test2_link_set_state(){
    Link *pl = NULL;

    PRINT_TEST_RESULT(link_set_state(pl , ABIERTO) == ERROR);
}



/*
 *  First get_id test
 */
void test1_link_get_id(){
    Link *pl = NULL;
    pl = link_create(13);

    PRINT_TEST_RESULT(link_get_id(pl) == 13);
    link_destroy(pl);
}

/*
 *  Second get_id test
 */
void test2_link_get_id(){
    Link *pl = NULL;

    PRINT_TEST_RESULT(link_get_id(pl) == NO_ID);
}



/*
 *  First get_name test
 */
void test1_link_get_name(){
    Link *pl = NULL;
    pl = link_create(1);
    
    link_set_name(pl, "DEMASIADO");
    PRINT_TEST_RESULT(strcmp(link_get_name(pl),"DEMASIADO") == 0);
    link_destroy(pl);
}

/*
 *  Second get_name test
 */
void test2_link_get_name(){
    Link *pl = NULL;
    
    PRINT_TEST_RESULT(link_get_name(pl) == NULL);
}


/*
 *  First get_link1 test
 */
void test1_link_get_link1(){
    Link *pl = NULL;
    pl = link_create(19);
    
    link_set_link1(pl, 3);
    PRINT_TEST_RESULT(link_get_link1(pl) == 3);
    link_destroy(pl);
}

/*
 *  Second get_link1 test
 */
void test2_link_get_link1(){
    Link *pl = NULL;
    PRINT_TEST_RESULT(link_get_link1(pl) == NO_ID);
}



/*
 *  First get_link2 test
 */
void test1_link_get_link2(){
    Link *pl = NULL;
    pl = link_create(19);
    
    link_set_link2(pl, 3);
    PRINT_TEST_RESULT(link_get_link2(pl) == 3);
    link_destroy(pl);
}

/*
 *  Second get_link2 test
 */
void test2_link_get_link2(){
    Link *pl = NULL;
    PRINT_TEST_RESULT(link_get_link2(pl) == NO_ID);
}

/*
 *  First get_state test
 */
void test1_link_get_state(){
    Link *pl = NULL;
    pl = link_create(9);

    link_set_state(pl, CERRADO);
    PRINT_TEST_RESULT(link_get_state(pl) == CERRADO);
    link_destroy(pl);
}

/*
 *  Second get_state test
 */
void test2_link_get_state(){
    Link *pl = NULL;
    PRINT_TEST_RESULT(link_get_state(pl) == DESCONOCIDO);
}
