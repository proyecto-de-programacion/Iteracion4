/**
 * @brief Tests the object module
 * 
 * @file   test_object.c
 * @author Alexandra Conache
 * @version 1.0
 * @date 08/04/2019
 *   
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../include/object.h"
#include "../include/test_object.h"
#include "../include/test.h"

#define MAX_TESTS 12 /*!< Maximum number of tests */
/**
 * @brief Runs the test
 * @param argc first argument
 * @param *argv[] second argument
 * 
 */
int main(int argc, char** argv) {

    int test = 0;
    int all = 1;

    if (argc < 2) {
        printf("Running all test for module Object:\n");
    } else {
        test = atoi(argv[1]);
        all = 0;
        printf("Running test %d:\t", test);
        if (test < 1 && test > MAX_TESTS) {
            printf("Error: unknown test %d\t", test);
            exit(EXIT_SUCCESS);
        }
    }


    if (all || test == 1) test1_object_create();
    if (all || test == 2) test2_object_create();
    if (all || test == 3) test1_object_get_id();
    if (all || test == 4) test2_object_get_id();
    if (all || test == 5) test1_object_set_name();
    if (all || test == 6) test2_object_set_name();
    if (all || test == 7) test1_object_set_description();
    if (all || test == 8) test2_object_set_description();
    if (all || test == 9) test1_object_get_name();
    if (all || test == 10) test2_object_get_name();
    if (all || test == 11) test1_object_get_description();
    if (all || test == 12) test2_object_get_description();


    PRINT_PASSED_PERCENTAGE;

    return 1;
}
/*
 *      First object_create test
 */
void test1_object_create(){
    Object *o =NULL;

    o = object_create(3);

    PRINT_TEST_RESULT(o != NULL);
    object_destroy(o);
}

/*
 *      Second object_create test
 */
void test2_object_create(){
    Object *o = NULL;

    o = object_create(9);

    PRINT_TEST_RESULT(object_get_id(o) == 9);
    object_destroy(o);
} 

/*
 *      First object_get_id test
 */
void test1_object_get_id(){
    Object *o = NULL;

    o = object_create(27);

    PRINT_TEST_RESULT(object_get_id(o) == 27);
    object_destroy(o);
}

/*
 *      Second object_get_id test
 */
void test2_object_get_id(){
    Object *o = NULL;

    PRINT_TEST_RESULT(object_get_id(o) == NO_ID);
} 

/*
 *      First object_set_name test
 */
void test1_object_set_name(){
    Object *o = NULL;
    o = object_create(1);
    PRINT_TEST_RESULT(object_set_name(o,"DAB") == OK);
    object_destroy(o);
} 

/*
 *      Second object_set_name test
 */
void test2_object_set_name(){
    Object *o = NULL;
    PRINT_TEST_RESULT(object_set_name(o,"DAB") == ERROR);

}
/*
 *      First object_set_description test
 */
void test1_object_set_description(){
    Object *o =NULL;
    o = object_create(1);
    PRINT_TEST_RESULT(object_set_description(o,"Objeto fabuloso") == OK);
    object_destroy(o);
}

/*
 *      Second object_set_description test
 */
void test2_object_set_description(){
    Object *o =NULL;
    PRINT_TEST_RESULT(object_set_description(o,"Objeto roto") != OK);

}

/* 
 *      First object_get_name test
 */
void test1_object_get_name(){
    Object *o = NULL;
    o = object_create(1);
    object_set_name(o,"DAB");
    PRINT_TEST_RESULT(strcmp(object_get_name(o),"DAB") == 0);
    object_destroy(o);
}
/*
 *      Second object_get_name test
 */
void test2_object_get_name(){
    Object *o = NULL;
    PRINT_TEST_RESULT(object_get_name(o)==NULL);
}

/*
 *      First object_get_description test
 */

void test1_object_get_description(){
    Object *o = NULL;
    o = object_create(1);
    object_set_description(o,"Objeto Fabuloso");
    PRINT_TEST_RESULT(strcmp(object_get_description(o),"Objeto Fabuloso")==0);
    object_destroy(o);
}

/*
 *      Second object_get_description test
 */
void test2_object_get_description(){
    Object *o = NULL;
    PRINT_TEST_RESULT(object_get_description(o) == NULL);
}

/*
 *      THE END... For Now  
 */
