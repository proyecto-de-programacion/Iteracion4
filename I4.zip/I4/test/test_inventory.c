/** 
 * @brief It tests Inventory module
 * 
 * @file test_inventory.c
 * @author CiroAlonso
 * @version 1.0
 * @date 10-04-2019
 */


#include <stdio.h>
#include <stdlib.h>
#include "../include/inventory.h"
#include "../include/test_inventory.h"
#include "../include/test.h"

#define MAX_TESTS 12 /*!< Maximum number of tests */

/** 
 * @brief Funcion principal de pruebas para el modulo inventory. 
 * 
 * Dos modos de ejecucion:
 *   1.-Si se ejecuta sin parametros se ejecutan todas las pruebas 
 *   2.-Si se ejecuta con un numero entre 1 y el numero de pruebas solo ejecuta 
 *      la prueba indicada  
 *  
 */

/**
 * @brief Runs the test
 * @param argc first argument
 * @param *argv[] second argument
 * 
 */
int main(int argc, char** argv) {

    int test = 0;
    int all = 1;

    if (argc < 2) {
        printf("Running all test for module inventory:\n");
    } else {
        test = atoi(argv[1]);
        all = 0;
        printf("Running test %d:\t", test);
        if (test < 1 && test > MAX_TESTS) {
            printf("Error: unknown test %d\t", test);
            exit(EXIT_SUCCESS);
        }
    }


    if (all || test == 1) test1_inventory_create();
    if (all || test == 2) test2_inventory_create(); 
    if (all || test == 3) test1_inventory_set_maxObjects();
    if (all || test == 4) test2_inventory_set_maxObjects();
    if (all || test == 5) test1_inventory_get_set();
    if (all || test == 6) test2_inventory_get_set();
    if (all || test == 7) test1_inventory_get_maxObjects();
    if (all || test == 8) test2_inventory_get_maxObjects();
    if (all || test == 9) test1_inventory_add_object();
    if (all || test == 10) test2_inventory_add_object();
    if (all || test == 11) test1_inventory_delete_object();
    if (all || test == 12) test2_inventory_delete_object();    
    if (all || test == 13) test3_inventory_delete_object();
    if (all || test == 14) test1_inventory_ask_id();
    if (all || test == 15) test2_inventory_ask_id();   
    if (all || test == 16) test3_inventory_ask_id();

    PRINT_PASSED_PERCENTAGE;

    return 1;
}

/*
 *  First inventory_create test
 */
void test1_inventory_create(){
    Inventory *pp = NULL;
    pp = inventory_create(1);;

    PRINT_TEST_RESULT(pp != NULL);
    inventory_destroy(pp);
}

/*
 *  Second inventory_create test
 */
void test2_inventory_create(){
    Inventory *podemos = NULL;
    podemos = inventory_create(4);

    PRINT_TEST_RESULT(podemos != NULL);
    inventory_destroy(podemos);
}




/*
 *  First set_maxObjects test
 */
void test1_inventory_set_maxObjects(){
    Inventory *pi = NULL;
    pi = inventory_create(2);

    PRINT_TEST_RESULT(inventory_set_maxObjects(pi, 7)== OK);
    inventory_destroy(pi);

}

/*
 *  Second set_maxObjects test
 */
void test2_inventory_set_maxObjects(){
    Inventory *pi = NULL;

    PRINT_TEST_RESULT(inventory_set_maxObjects(pi, 7) == ERROR);
}


/*
 *  First get_set test
 */
void test1_inventory_get_set(){
    Inventory *pi = NULL;
    pi = inventory_create(1);

    inventory_add_object(pi, 1);
    PRINT_TEST_RESULT(inventory_get_set(pi) != NULL);
    inventory_destroy(pi);

}

/*
 *  Second get_set test
 */
void test2_inventory_get_set(){
    Inventory *pi = NULL;

    PRINT_TEST_RESULT(inventory_get_set(pi)== NULL);
}



/*
 *  First get_maxObjects test
 */
void test1_inventory_get_maxObjects(){
    Inventory *pi = NULL;
    pi = inventory_create(1);

    inventory_set_maxObjects(pi, 7);
    PRINT_TEST_RESULT(inventory_get_maxObjects(pi) == 7);
    inventory_destroy(pi);

}

/*
 *  Second get_maxObjects test
 */
void test2_inventory_get_maxObjects(){
    Inventory *pi = NULL;

    PRINT_TEST_RESULT(inventory_get_maxObjects(pi) != 1);
}



/*
 *  First add_object test
 */
void test1_inventory_add_object(){
    Inventory *pi = NULL;
    pi = inventory_create(2);

    PRINT_TEST_RESULT(inventory_add_object(pi, 3) == OK);
    inventory_destroy(pi);

}

/*
 *  Second add_object test
 */
void test2_inventory_add_object(){
    Inventory *pi = NULL;

    PRINT_TEST_RESULT(inventory_add_object(pi, 2) == ERROR);
}



/*
 *  First delete_object test
 */
void test1_inventory_delete_object(){
    Inventory *pi = NULL;
    pi = inventory_create(1);
    
    inventory_add_object(pi, 4);
    PRINT_TEST_RESULT(inventory_delete_object(pi, 4) == OK);
    inventory_destroy(pi);

}

/*
 *  Second delete_object test
 */
void test2_inventory_delete_object(){
    Inventory *pi = NULL;
    pi = inventory_create(4);

    inventory_add_object(pi, 5);
    PRINT_TEST_RESULT(inventory_delete_object(pi, 4) == ERROR);
    inventory_destroy(pi);

}

/*
 *  Third delete_object test
 */
void test3_inventory_delete_object(){
    Inventory *pi = NULL;

    PRINT_TEST_RESULT(inventory_delete_object(pi, 4) == ERROR);
}


/*
 *  First ask_id test
 */
void test1_inventory_ask_id(){
    Inventory *pi = NULL;
    pi = inventory_create(6);
    
    inventory_set_maxObjects(pi,2);
    inventory_add_object(pi, 1);

    PRINT_TEST_RESULT(inventory_ask_id(pi, 1) == TRUE);
    inventory_destroy(pi);

}

/*
 *  Second ask_id test
 */
void test2_inventory_ask_id(){
    Inventory *pi = NULL;
    PRINT_TEST_RESULT(inventory_ask_id(pi, 4) == FALSE);
}

/*
 *  Third ask_id test
 */
void test3_inventory_ask_id(){
    Inventory *pi = NULL;
    pi = inventory_create(2);

    inventory_add_object(pi, 3);
    PRINT_TEST_RESULT(inventory_ask_id(pi, 4) == FALSE);
    inventory_destroy(pi);
}

