var searchData=
[
  ['player_5flocation',['player_location',['../struct__Player.html#ace02a497c4bba6c50e45c70c352038ee',1,'_Player']]],
  ['players',['players',['../struct__Game.html#a824916e50859e02758ec20526a397885',1,'_Game']]]
];
