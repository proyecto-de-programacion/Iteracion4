var searchData=
[
  ['link_5fcreate',['link_create',['../link_8h.html#a8090d7f529cfd6a2fc5df3dd379fe514',1,'link_create(Id id):&#160;link.c'],['../link_8c.html#a8090d7f529cfd6a2fc5df3dd379fe514',1,'link_create(Id id):&#160;link.c']]],
  ['link_5fdestroy',['link_destroy',['../link_8h.html#a117e4e5a82b23b805052d1eace34d068',1,'link_destroy(Link *link):&#160;link.c'],['../link_8c.html#a117e4e5a82b23b805052d1eace34d068',1,'link_destroy(Link *link):&#160;link.c']]],
  ['link_5fget_5fid',['link_get_id',['../link_8h.html#a2bbd320f995a72b2ea7ea639b1c81892',1,'link_get_id(Link *link):&#160;link.c'],['../link_8c.html#a2bbd320f995a72b2ea7ea639b1c81892',1,'link_get_id(Link *link):&#160;link.c']]],
  ['link_5fget_5flink1',['link_get_link1',['../link_8h.html#a5ab57cf8161d09e8cda55c234d22ab66',1,'link_get_link1(Link *link):&#160;link.c'],['../link_8c.html#a5ab57cf8161d09e8cda55c234d22ab66',1,'link_get_link1(Link *link):&#160;link.c']]],
  ['link_5fget_5flink2',['link_get_link2',['../link_8h.html#ad274fe544465f3684d22b2a4dfa2c0bd',1,'link_get_link2(Link *link):&#160;link.c'],['../link_8c.html#ad274fe544465f3684d22b2a4dfa2c0bd',1,'link_get_link2(Link *link):&#160;link.c']]],
  ['link_5fget_5fname',['link_get_name',['../link_8h.html#aaab4c9c7d5492873cafd9e11dc0f8059',1,'link_get_name(Link *link):&#160;link.c'],['../link_8c.html#aaab4c9c7d5492873cafd9e11dc0f8059',1,'link_get_name(Link *link):&#160;link.c']]],
  ['link_5fget_5fstate',['link_get_state',['../link_8h.html#a8bebb185e941f72f46cc982e4286f320',1,'link_get_state(Link *link):&#160;link.c'],['../link_8c.html#a8bebb185e941f72f46cc982e4286f320',1,'link_get_state(Link *link):&#160;link.c']]],
  ['link_5fprint',['link_print',['../link_8h.html#a95ea756dad592e65440a33dfbe47edcf',1,'link_print(Link *link):&#160;link.c'],['../link_8c.html#a95ea756dad592e65440a33dfbe47edcf',1,'link_print(Link *link):&#160;link.c']]],
  ['link_5fset_5flink1',['link_set_link1',['../link_8h.html#a526a62eef81c93938b7e8ee4a754c63c',1,'link_set_link1(Link *link, Id id):&#160;link.c'],['../link_8c.html#a526a62eef81c93938b7e8ee4a754c63c',1,'link_set_link1(Link *link, Id id):&#160;link.c']]],
  ['link_5fset_5flink2',['link_set_link2',['../link_8h.html#a5e595d652382a65538d7017b82774d42',1,'link_set_link2(Link *link, Id id):&#160;link.c'],['../link_8c.html#a5e595d652382a65538d7017b82774d42',1,'link_set_link2(Link *link, Id id):&#160;link.c']]],
  ['link_5fset_5fname',['link_set_name',['../link_8h.html#a6c7a3bd7a856288c377edbcd045912e6',1,'link_set_name(Link *link, char *name):&#160;link.c'],['../link_8c.html#a6c7a3bd7a856288c377edbcd045912e6',1,'link_set_name(Link *link, char *name):&#160;link.c']]],
  ['link_5fset_5fstate',['link_set_state',['../link_8h.html#a9f09db9e578370893abd004a575ff828',1,'link_set_state(Link *link, STATE state):&#160;link.c'],['../link_8c.html#a9f09db9e578370893abd004a575ff828',1,'link_set_state(Link *link, STATE state):&#160;link.c']]]
];
