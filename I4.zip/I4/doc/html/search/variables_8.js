var searchData=
[
  ['id',['id',['../struct__Die.html#a0887af562dda760409957f13619d36f1',1,'_Die::id()'],['../struct__Inventory.html#a73dcd4e1c702c8234092eac3ca2753f6',1,'_Inventory::id()'],['../struct__Object.html#a3cff7a0e8dc4e9d23895ed9af1b7653a',1,'_Object::id()'],['../struct__Player.html#a60d635cd063816a9c1bd873f4868bb90',1,'_Player::id()'],['../struct__Space.html#a70cb461deb9ac073e401b607339b567f',1,'_Space::id()']]],
  ['illuminate',['illuminate',['../struct__Object.html#a6e4edc37e6d8a5237a501c432a4296ca',1,'_Object']]],
  ['inventory',['inventory',['../struct__Player.html#a5e02924cb82ca61f74ba414d190aa29b',1,'_Player']]]
];
