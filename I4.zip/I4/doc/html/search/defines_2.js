var searchData=
[
  ['init_5fvalue',['INIT_VALUE',['../types_8h.html#a1cec278569efadde1ea6834da3dfbc70',1,'types.h']]]
];
