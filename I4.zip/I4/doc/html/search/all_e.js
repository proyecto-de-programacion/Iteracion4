var searchData=
[
  ['pickup',['PICKUP',['../command_8h.html#acea6bca51a84314189b066f9c395d193abd6c69691b68642f5c619c8be829d3db',1,'command.h']]],
  ['player',['Player',['../player_8h.html#af30e2030635a69690f85e48bc6ef202f',1,'player.h']]],
  ['player_2ec',['player.c',['../player_8c.html',1,'']]],
  ['player_2eh',['player.h',['../player_8h.html',1,'']]],
  ['player_5fcreate',['player_create',['../player_8h.html#a97ea1d0deda3c51ef6ce63a13dab7a38',1,'player_create(Id id):&#160;player.c'],['../player_8c.html#a97ea1d0deda3c51ef6ce63a13dab7a38',1,'player_create(Id id):&#160;player.c']]],
  ['player_5fdestroy',['player_destroy',['../player_8h.html#a68e324aa5064e27d0a2f38aafb6809ad',1,'player_destroy(Player *player):&#160;player.c'],['../player_8c.html#a68e324aa5064e27d0a2f38aafb6809ad',1,'player_destroy(Player *player):&#160;player.c']]],
  ['player_5fdrop_5fobject',['player_drop_object',['../player_8h.html#a4987a0f617b03cc6fe72d8ef556c8278',1,'player_drop_object(Player *player, Id object_id):&#160;player.c'],['../player_8c.html#a4987a0f617b03cc6fe72d8ef556c8278',1,'player_drop_object(Player *player, Id object_id):&#160;player.c']]],
  ['player_5fget_5fid',['player_get_id',['../player_8h.html#af5a101ec91427951c5875569a8709956',1,'player_get_id(Player *player):&#160;player.c'],['../player_8c.html#af5a101ec91427951c5875569a8709956',1,'player_get_id(Player *player):&#160;player.c']]],
  ['player_5fget_5finventory',['player_get_inventory',['../player_8h.html#a270da6469a85e0c2b7f9f4088d290051',1,'player_get_inventory(Player *player):&#160;player.c'],['../player_8c.html#a270da6469a85e0c2b7f9f4088d290051',1,'player_get_inventory(Player *player):&#160;player.c']]],
  ['player_5fget_5flocation',['player_get_location',['../player_8h.html#aa50ce77ab79af7166d749619fd60acfe',1,'player_get_location(Player *player):&#160;player.c'],['../player_8c.html#aa50ce77ab79af7166d749619fd60acfe',1,'player_get_location(Player *player):&#160;player.c']]],
  ['player_5fget_5fname',['player_get_name',['../player_8h.html#a6622c02be2fe230a5c0df66385a13ece',1,'player_get_name(Player *player):&#160;player.c'],['../player_8c.html#a6622c02be2fe230a5c0df66385a13ece',1,'player_get_name(Player *player):&#160;player.c']]],
  ['player_5fhas_5fobject',['player_has_object',['../player_8h.html#ac81b7c466d5447782c3e31a40fa15bd0',1,'player_has_object(Player *player, Id id):&#160;player.c'],['../player_8c.html#ac81b7c466d5447782c3e31a40fa15bd0',1,'player_has_object(Player *player, Id id):&#160;player.c']]],
  ['player_5flocation',['player_location',['../struct__Player.html#ace02a497c4bba6c50e45c70c352038ee',1,'_Player']]],
  ['player_5fprint',['player_print',['../player_8h.html#aa0f2f8b4d1b63a60ef927d47aa45dbd1',1,'player_print(Player *player):&#160;player.c'],['../player_8c.html#aa0f2f8b4d1b63a60ef927d47aa45dbd1',1,'player_print(Player *player):&#160;player.c']]],
  ['player_5fset_5finventory',['player_set_inventory',['../player_8h.html#a1be1d7a1376963de69a0b55af3d6f673',1,'player_set_inventory(Player *player, Id id):&#160;player.c'],['../player_8c.html#a1be1d7a1376963de69a0b55af3d6f673',1,'player_set_inventory(Player *player, Id id):&#160;player.c']]],
  ['player_5fset_5flocation',['player_set_location',['../player_8h.html#ac8ace1a1b6b11bc7f92a71a3922e4b83',1,'player_set_location(Player *player, Id id):&#160;player.c'],['../player_8c.html#ac8ace1a1b6b11bc7f92a71a3922e4b83',1,'player_set_location(Player *player, Id id):&#160;player.c']]],
  ['player_5fset_5fname',['player_set_name',['../player_8h.html#a6a30809f7775f5c2d3bef47d92769e59',1,'player_set_name(Player *player, char *name):&#160;player.c'],['../player_8c.html#a6a30809f7775f5c2d3bef47d92769e59',1,'player_set_name(Player *player, char *name):&#160;player.c']]],
  ['players',['players',['../struct__Game.html#a824916e50859e02758ec20526a397885',1,'_Game']]]
];
