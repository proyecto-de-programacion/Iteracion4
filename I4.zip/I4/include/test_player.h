/**
 *      @brief Declares the tests for the player module
 * 
 *      @file test_player.h
 *      @author Alexandra Conache
 *      @version 1.0
 *      @date 08-04-2019
 * 
 * 
 */

#ifndef TEST_OBJECT_H
#define TEST_OBJECT_H
/**
 *      @test Tests the create a player function
 *      @pre  Parameter: -
 *      @post Return: non Null pointer player
 */
void test1_player_create();
/**
 *      @test Tests the create a player function
 *      @pre  Parameter: NO_ID as the player's id
 *      @post Return: a NULL pointer player
 */
void test2_player_create();
/**
 *      @test Tests the return the player's id function
 *      @pre  Parameter: the id we assign to the player
 *      @post Return: returns the id assigned
 */
void test1_player_get_id();
/**
 *      @test Tests the return the player's id function
 *      @pre  Parameter: a NULL player
 *      @post Return: return the player's id that is NO_ID 
 */
void test2_player_get_id();
/**
 *      @test Tests the assign a name to a player function
 *      @pre  Parameter: the name we want to assign
 *      @post Return: 0 to the string compare of names we did
 */
void test1_player_set_name();
/**
 *      @test Tests the assign a name to a player function
 *      @pre  Parameter: a NULL player
 *      @post Return: must return ERROR
 */
void test2_player_set_name();
/**
 *      @test Tests the assign an inventory to the player function
 *      @pre  Parameter: the inventory id
 *      @post Return: must return OK
 */
void test1_player_set_inventory();
/**
 *      @test Tests the assign an inventory to the player
 *      @pre  Parameter: a NULL player pointer
 *      @post Return: must return ERROR
 */
void test2_player_set_inventory();
/**
 *      @test Tests the return the player's name function
 *      @pre  Parameter: the name we want assigned to the player
 *      @post Return: 0 for the string comparison we did of the name
 */
void test1_player_get_name();
/**
 *      @test Tests the return the player's name function
 *      @pre  Parameter: a NULL player pointer
 *      @post Return: must return NULL
 */
void test2_player_get_name();
/**
 *      @test Tests the return the player's inventory function
 *      @pre  Parameter: the inventorie's id
 *      @post Return: returns something other than NULL
 */
void test1_player_get_inventory();
/**
 *      @test Tests the return the player's inventory function
 *      @pre  Parameter: a NULL player pointer
 *      @post Return: must return NULL
 */
void test2_player_get_inventory();
/**
 *      @test Tests the assign the player a location function
 *      @pre  Parameter: the location's id
 *      @post Return: must return OK
 */
void test1_player_set_location();
/**
 *      @test Tests the assign the player a location function
 *      @pre  Parameter: a NULL player pointer
 *      @post Return: returns something that's not OK
 */
void test2_player_set_location();
/**
 *      @test Tests the return the player's location function
 *      @pre  Parameter: the player's location id
 *      @post Return: must return the set location's id
 */
void test1_player_get_location();
/**
 *      @test Tests the return the palyer's location function
 *      @pre  Parameter: a NULL player pointer
 *      @post Return: must return NO_ID as the location's id
 */
void test2_player_get_location();
/**
 *      @test Tests the makes a player drop an object function
 *      @pre  Parameter: the object-we-want-to-drop's id
 *      @post Return: must return ERROR
 */
void test1_player_drop_object();
/**
 *      @test Tests the makes a player drop an object function
 *      @pre  Parameter: a NULL player pointer
 *      @post Return: must return something that's not OK
 */
void test2_player_drop_object();
/**
 *      @test Tests the function that checks if the player has a specific object
 *      @pre  Parameter: the object's id
 *      @post Return: must return ERROR
 */
void test1_player_has_object();
/**
 *      @test Tests the function that checks if the player has a specific object
 *      @pre  Parameter: a NULL player pointer
 *      @post Return: must return something that's not OK
 */
void test2_player_has_object();

#endif