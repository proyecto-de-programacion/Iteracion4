var searchData=
[
  ['state',['STATE',['../types_8h.html#a275a67132f10277ada3a0ee3d616b647',1,'types.h']]],
  ['status',['STATUS',['../types_8h.html#a32c27cc471df37f4fc818d65de0a56c4',1,'types.h']]]
];
