var searchData=
[
  ['area',['Area',['../screen_8h.html#acfdfc42f6522d75fa3c16713afde8127',1,'screen.h']]],
  ['arid',['arId',['../struct__Set.html#af9d80cb8bf65c82bfcd0caf990dcfab3',1,'_Set']]]
];
