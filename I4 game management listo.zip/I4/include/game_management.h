/** 
* @brief It defines a textual game reader
* 
* @file game_management.h
* @author Alexandra Conache
* @version 3.0 
* @date 25/02/2019
*/


#ifndef game_management_H
#define game_management_H

#include "command.h"
#include "game.h"



/**
*      @brief Reads and loads the spaces 
*                              
*      In charge of reading the positions of the boxes and how the are interconnected                        
*      and load the spaces required from the file
*       
*
*      @param game structure Game from file game.h 
*      @param filename necessary to load spaces 
*
*      @date  8/03/2019 
*      @author Alexandra Conache    
*      @return OK or ERROR if the function worked or not                 
*/ 
STATUS game_management_load_spaces(Game* game, char* filename);

/**
*      @brief Reads and loads the objects 
*                              
*      In charge of reading the positions of the boxes and how the are interconnected                        
*      and load the objects required from the file
*       
*
*      @param game structure Game from file game.h 
*      @param filename necessary to load objects 

*      @date  8/03/2019 
*      @author Alexandra Conache  
*      @return OK or ERROR if the function worked or not                   
*/
STATUS game_management_load_objects(Game* game, char* filename);


/**
*      @brief Reads and loads the links 
*                              
*      In charge of reading the positions of the boxes and how the are interconnected                        
*      and load the links required from the file
*       
*
*      @param game structure Game from file game.h 
*      @param filename necessary to load links 
*      @date  01/04/2019 
*      @author Alexandra Conache & Sara Erika Catana 
*      @return OK or ERROR if the function worked or not                  
*/
STATUS game_management_load_links(Game* game, char* filename);
/**
 *     @brief Reads and loads the player
 * 
 * 
 *     @date 07/05/2019
 *     @author Alexandra Conache
 *     @param game structure Game
 *     @param filename necessary to load player
 *     @return OK or ERROR if the function worked or not
 * 
 */
STATUS game_management_load_player(Game* game, char* filename);
/**
 *     @brief Reads and loads the game
 * 
 * 
 *     @date 07/05/2019
 *     @author Alexandra Conache
 *     @param game structure Game
 *     @param filename necessary to load the game
 *     @return OK or ERROR if the function worked or not
 * 
 */
STATUS game_management_load_game(Game* game, char* filename);
/**
 *     @brief Writes and saves the game
 * 
 * 
 *     @date 07/05/2019
 *     @author Alexandra Conache && Ciro Alonso Aquino
 *     @param structure Game
 *     @param filename necessary to save the game to
 *     @return OK or ERROR if the function worked or not
 * 
 */
STATUS game_management_save_game(Game* game, char* filename);
/**
 *     @brief Writes and saves the spaces
 * 
 * 
 *     @date 07/05/2019
 *     @author Alexandra Conache && Ciro Alonso Aquino
 *     @param f file we save the spaces to
 *     @param space structure Space
 *     @return OK or ERROR if the function worked or not
 * 
 */
STATUS game_management_save_spaces(FILE *f, Space* space);
/**
 *     @brief Writes and saves the objects
 * 
 * 
 *     @date 07/05/2019
 *     @author Alexandra Conache && Ciro Alonso Aquino
 *     @param f file we save the objects to
 *     @param game structure Game
 *     @param object structure Object
 *     @return OK or ERROR if the function worked or not
 * 
 */
STATUS game_management_save_objects(FILE *f, Game* game, Object* object);
/**
 *     @brief Writes and saves the links
 * 
 * 
 *     @date 07/05/2019
 *     @author Alexandra Conache && Ciro Alonso Aquino
 *     @param f file we save the links to
 *     @param link structure Link
 *     @return OK or ERROR if the function worked or not
 * 
 */
STATUS game_management_save_links(FILE *f, Link* link);
/**
 *     @brief Writes and saves the player
 * 
 * 
 *     @date 07/05/2019
 *     @author Alexandra Conache && Ciro Alonso Aquino
 *     @param f file we save the player to
 *     @param player structure Player
 *     @return OK or ERROR if the function worked or not
 * 
 */
STATUS game_management_save_player(FILE *f, Player* player);


#endif