/** 
 * @brief It declares the tests for the inventory module
 * 
 * @file test_inventory.h
 * @author CiroAlonso
 * @version 1.0 
 * @date 10-04-19
 */

#ifndef TEST_LINK_H
#define TEST_LINK_H

/**
 *      @test   Tests the inventory creation function
 *      @pre    Parameter: the id of the new link
 *      @post   Return: a non NULL pointer to the inventory created
 */
void test1_link_create();

/**
 *      @test   Tests the inventory creation function
 *      @pre    Parameter: a null pointer
 *      @post   Return: a NULL pointer to the inventory created
 */
void test2_link_create();

/**
 *      @test   Tests the assign an inventory's name function
 *      @pre    Parameter: the name we want to assign
 *      @post   Return: OK
 */
void test1_link_set_name();

/**
 *      @test   Tests the assign an inventory's name function
 *      @pre    Parameter: the name we want to assign
 *      @post   Return: ERROR
 */
void test2_link_set_name();

/**
 *      @test   Tests the set_link1 function
 *      @pre    Parameter: the name we want to assign
 *      @post   Return: OK
 */
void test1_link_set_link1();

/**
 *      @test   Tests the set_link1 function
 *      @pre    Parameter: the id we want to assign
 *      @post   Return: ERROR
 */
void test2_link_set_link1();

/**
 *      @test   Tests the set_link2 function
 *      @pre    Parameter: the id we want to assign
 *      @post   Return: OK
 */
void test1_link_set_link2();

/**
 *      @test   Tests the set_link2 function
 *      @pre    Parameter: the id we want to assign
 *      @post   Return: ERROR
 */
void test2_link_set_link2();

/**
 *      @test   Tests the set_state function
 *      @pre    Parameter: the state we want to assign
 *      @post   Return: OK
 */
void test1_link_set_state();

/**
 *      @test   Tests the set_state function
 *      @pre    Parameter: the state we want to assign
 *      @post   Return: ERROR
 */
void test2_link_set_state();

/**
 *      @test   Tests the get_id function
 *      @pre    Parameter: id for the link
 *      @post   Return:  the id of the structure
 */
void test1_link_get_id();

/**
 *      @test   Tests the get_id function
 *      @pre    Parameter: Null link pointer
 *      @post   Return:  NO_ID
 */
void test2_link_get_id();

/**
 *      @test   Tests the get_name function
 *      @pre    Parameter: a non Null link pointer and a char
 *      @post   Return:  a pointer to the name
 */
void test1_link_get_name();

/**
 *      @test   Tests the get_name function
 *      @pre    Parameter: Null link pointer
 *      @post   Return:  NULL
 */
void test2_link_get_name();

/**
 *      @test   Tests the get_link1 function
 *      @pre    Parameter:  a non null link pointer and a link1 id
 *      @post   Return:  the id of the link1
 */
void test1_link_get_link1();

/**
 *      @test   Tests the get_link1 function
 *      @pre    Parameter: Null link pointer
 *      @post   Return:  NO_ID
 */
void test2_link_get_link1();

/**
 *      @test   Tests the get_link2 function
 *      @pre    Parameter:  a non null link pointer and a link2 id
 *      @post   Return:  the id of the link2
 */
void test1_link_get_link2();

/**
 *      @test   Tests the get_link2 function
 *      @pre    Parameter: Null link pointer
 *      @post   Return:  NO_ID
 */
void test2_link_get_link2();

/**
 *      @test   Tests the get_state function
 *      @pre    Parameter:  a non null link pointer and a state
 *      @post   Return:  the state of the structure
 */
void test1_link_get_state();

/**
 *      @test   Tests the get_state function
 *      @pre    Parameter: Null link pointer
 *      @post   Return:  DESCONOCIDO
 */
void test2_link_get_state();


#endif