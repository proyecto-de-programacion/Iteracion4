var searchData=
[
  ['descript',['descript',['../struct__Graphic__engine.html#a8a4927aedd398b43f86c871f197edf1d',1,'_Graphic_engine']]],
  ['description',['description',['../struct__Game.html#aed8ad2d80067fb8ae9f1634e90605baa',1,'_Game::description()'],['../struct__Object.html#add691deed525492ad692cc2f5bccfe90',1,'_Object::description()'],['../struct__Space.html#a41a1dbfab1d88b732db50d7335c2f328',1,'_Space::description()']]],
  ['dice',['dice',['../struct__Game.html#a0582823fab0c98f3c51c2ecf3ad6796e',1,'_Game']]]
];
