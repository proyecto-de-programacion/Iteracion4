var searchData=
[
  ['die_5fcreate',['die_create',['../die_8h.html#a413bced882cd5cadbb1d8feaf367ed3f',1,'die_create(Id id):&#160;die.c'],['../die_8c.html#a413bced882cd5cadbb1d8feaf367ed3f',1,'die_create(Id id):&#160;die.c']]],
  ['die_5fdestroy',['die_destroy',['../die_8h.html#a2115999335e58f733d846be485cfb783',1,'die_destroy(Die *die):&#160;die.c'],['../die_8c.html#a2115999335e58f733d846be485cfb783',1,'die_destroy(Die *die):&#160;die.c']]],
  ['die_5fget_5fid',['die_get_id',['../die_8h.html#a57c9a2627bb3a1ca04fe55d72bd6a5ea',1,'die_get_id(Die *die):&#160;die.c'],['../die_8c.html#a57c9a2627bb3a1ca04fe55d72bd6a5ea',1,'die_get_id(Die *die):&#160;die.c']]],
  ['die_5fget_5flastroll',['die_get_lastRoll',['../die_8h.html#a78c4189a48c9c8e007ecd79e25c2ed32',1,'die_get_lastRoll(Die *d):&#160;die.c'],['../die_8c.html#a78c4189a48c9c8e007ecd79e25c2ed32',1,'die_get_lastRoll(Die *d):&#160;die.c']]],
  ['die_5fprint',['die_print',['../die_8h.html#a6ab2e5a9dcbd7ba3bf9ac6ebb183ac97',1,'die_print(Die *die):&#160;die.c'],['../die_8c.html#a6ab2e5a9dcbd7ba3bf9ac6ebb183ac97',1,'die_print(Die *die):&#160;die.c']]],
  ['die_5froll',['die_roll',['../die_8h.html#a06289514edbedf660c4b043f78e859fc',1,'die_roll(Die *die):&#160;die.c'],['../die_8c.html#a06289514edbedf660c4b043f78e859fc',1,'die_roll(Die *die):&#160;die.c']]]
];
