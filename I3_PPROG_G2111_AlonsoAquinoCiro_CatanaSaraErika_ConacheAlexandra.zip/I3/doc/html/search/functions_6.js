var searchData=
[
  ['object_5fcreate',['object_create',['../object_8h.html#abb0cd30fca5fbddf137c6c04df66bbc7',1,'object_create(Id id):&#160;object.c'],['../object_8c.html#abb0cd30fca5fbddf137c6c04df66bbc7',1,'object_create(Id id):&#160;object.c']]],
  ['object_5fdestroy',['object_destroy',['../object_8h.html#a19d6d51fee809e3801893eefc789f4b4',1,'object_destroy(Object *object):&#160;object.c'],['../object_8c.html#a19d6d51fee809e3801893eefc789f4b4',1,'object_destroy(Object *object):&#160;object.c']]],
  ['object_5fget_5fdescription',['object_get_description',['../object_8h.html#ab92f583fcb6e3000ebe48cc04c5853cd',1,'object_get_description(Object *object):&#160;object.c'],['../object_8c.html#ab92f583fcb6e3000ebe48cc04c5853cd',1,'object_get_description(Object *object):&#160;object.c']]],
  ['object_5fget_5fid',['object_get_id',['../object_8h.html#ac5af152381a21853c6a28cc120e8e7fe',1,'object_get_id(Object *object):&#160;object.c'],['../object_8c.html#ac5af152381a21853c6a28cc120e8e7fe',1,'object_get_id(Object *object):&#160;object.c']]],
  ['object_5fget_5fname',['object_get_name',['../object_8h.html#a7954dbdd53d8b5dc259993f04bba28f8',1,'object_get_name(Object *object):&#160;object.c'],['../object_8c.html#a7954dbdd53d8b5dc259993f04bba28f8',1,'object_get_name(Object *object):&#160;object.c']]],
  ['object_5fprint',['object_print',['../object_8h.html#adebb77fb5d33fc70616ab3b2b64c27ce',1,'object_print(Object *object):&#160;object.c'],['../object_8c.html#adebb77fb5d33fc70616ab3b2b64c27ce',1,'object_print(Object *object):&#160;object.c']]],
  ['object_5fset_5fdescription',['object_set_description',['../object_8h.html#ae88627a8873d8f08fba9c0470a19cfc0',1,'object_set_description(Object *object, char *description):&#160;object.c'],['../object_8c.html#ae88627a8873d8f08fba9c0470a19cfc0',1,'object_set_description(Object *object, char *description):&#160;object.c']]],
  ['object_5fset_5fname',['object_set_name',['../object_8h.html#ac15dc062c857503ec0ca66037caffd80',1,'object_set_name(Object *object, char *name):&#160;object.c'],['../object_8c.html#ac15dc062c857503ec0ca66037caffd80',1,'object_set_name(Object *object, char *name):&#160;object.c']]]
];
