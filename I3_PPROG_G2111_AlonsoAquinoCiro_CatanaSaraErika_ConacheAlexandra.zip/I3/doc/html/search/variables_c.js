var searchData=
[
  ['objects',['objects',['../struct__Game.html#ad45bf5645a26e546d0060a2e61f9cf81',1,'_Game::objects()'],['../struct__Space.html#a661ed8b0fc8085b6db70188aa5085625',1,'_Space::objects()']]]
];
